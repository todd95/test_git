import java.util.*;

public class movie {
	private String title;
	private String director;
	private String year;
	private String genre;
	private String rating;
	private String description;
	private ArrayList<String> actors = new ArrayList<String>();
	private ArrayList<String> writers = new ArrayList<String>();
	
	public movie(){};
	
	public void setTitle(String t)
	{
		title = t;
	}
	public void setDirector(String d)
	{
		director = d;
	}
	public void setYear(String y)
	{
		year = y;
	}
	public void setGenre(String g)
	{
		genre = g;
	}
	public void setRating(String r)
	{
		rating = r;
	}
	public void setDescription(String de)
	{
		description = de;
	}
	public void addActor(String s)
	{
		actors.add(s);
	}
	public void addWriter(String w)
	{
		writers.add(w);
	}
	
	
	
	
	
	public String getTitle()
	{
		return title;
	}
	public String getDirector()
	{
		return director;
	}
	public String getYear()
	{
		return year;
	}
	public String getGenre()
	{
		return genre;
	}
	public String getRating()
	{
		return rating;
	}
	public String getDescription()
	{
		return description;
	}
	public ArrayList<String> getActors()
	{
		return actors;
	}
	public ArrayList<String> getWriters()
	{
		return writers;
	}
	
	
}
