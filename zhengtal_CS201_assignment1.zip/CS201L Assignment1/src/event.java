public class event {
	private String action;
	private String rating;
	private String mo;
	
	public event(String ac, String ra, String mm)
	{
		action = ac;
		rating = ra;
		mo = mm;
	};
	
	public void setAction(String g)
	{
		action = g;
	}
	
	public void setMovie(String m)
	{
		mo = m;
	}
	
	public void setRating(String r)
	{
		rating = r;
	}
	
	public String getAction()
	{
		return action;
	}
	
	public String getMovie()
	{
		return mo;
	}
	
	public String getRating()
	{
		return rating;
	}
	public String printEvent()
	{
		if (!rating.equals(""))
		{
			return(action+" the movie ‘" +mo+"  and rated " + rating+ "'.");
		}
		return  (action+" the movie ‘" + mo+"'.");
	}
}
