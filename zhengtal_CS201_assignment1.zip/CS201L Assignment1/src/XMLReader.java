import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import java.util.*;


public class XMLReader{
	
	
	public ArrayList<movie> readMovies()
	{
		try
		{
		
			File inputFile = new File("Assignment1.txt");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
//			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			// now genres lvel
			doc.getDocumentElement();
//			NodeList nList = doc.getElementsByTagName("genres");
			NodeList nList2 = doc.getElementsByTagName("movies");
			
			//genres
//			Node nNode = nList.item(0);
			//movies
			Node nNode2 = nList2.item(0);
			//users
			
			//list of genre
			
			
			
//			Element eElement = (Element) nNode;
			Element eElement2 = (Element) nNode2;

			
			
			
			
			//movies
			
			NodeList nList4 = eElement2.getElementsByTagName("movie");
			ArrayList<movie> mov = new ArrayList<movie>();
			for (int i4=0;i4<nList4.getLength();i4++)
			{
				Node nNode4 = nList4.item(i4);
				Element eElement4 = (Element) nNode4;
//				System.out.println("title : " + eElement4.getElementsByTagName("title").item(0).getTextContent());
//				System.out.println("director : " + eElement4.getElementsByTagName("director").item(0).getTextContent());
//				System.out.println("year : " + eElement4.getElementsByTagName("year").item(0).getTextContent());
//				System.out.println("rating : " + eElement4.getElementsByTagName("rating").item(0).getTextContent());
//				System.out.println("description : " + eElement4.getElementsByTagName("description").item(0).getTextContent());
//				System.out.println("genre : " + eElement4.getElementsByTagName("genre").item(0).getTextContent());
				
				
				mov.add(new movie());
				mov.get(i4).setTitle(eElement4.getElementsByTagName("title").item(0).getTextContent());
				mov.get(i4).setYear(eElement4.getElementsByTagName("year").item(0).getTextContent());
				mov.get(i4).setDescription(eElement4.getElementsByTagName("description").item(0).getTextContent());
				mov.get(i4).setRating(eElement4.getElementsByTagName("rating").item(0).getTextContent());
				mov.get(i4).setDirector(eElement4.getElementsByTagName("director").item(0).getTextContent());
				mov.get(i4).setGenre(eElement4.getElementsByTagName("genre").item(0).getTextContent());
				
				
				
				
				Element eElement41 = (Element) eElement4.getElementsByTagName("writers").item(0);
				NodeList nList41 = eElement41.getElementsByTagName("writer");
				for (int i41=0;i41<nList41.getLength();i41++)
				{
//					System.out.println("writer : " +nList41.item(i41).getTextContent());
					mov.get(i4).addWriter(eElement4.getElementsByTagName("writer").item(i41).getTextContent());
				}
				
				Element eElement42 = (Element) eElement4.getElementsByTagName("actors").item(0);
				NodeList nList42 = eElement42.getElementsByTagName("actor");
				for (int i42=0;i42<nList42.getLength();i42++)
				{
//					System.out.println("actor : " +nList42.item(i42).getTextContent());
					mov.get(i4).addActor(eElement4.getElementsByTagName("actor").item(i42).getTextContent());
				}

			}
			
			
			return mov;
		}catch (Exception e) 
		{
			System.out.println(e.getMessage());
			return null;
		}
		
	}
	public ArrayList<user> readUsers()
	{
		try
		{
			File inputFile = new File("Assignment1.txt");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			doc.getDocumentElement();
			NodeList nList3 = doc.getElementsByTagName("users");
			Node nNode3 = nList3.item(0);
			Element eElement3 = (Element) nNode3;
			ArrayList<user> use = new ArrayList<user>();
			NodeList nList5 = eElement3.getElementsByTagName("user");
			for (int i5=0;i5<nList5.getLength();i5++)
			{
				Node nNode5 = nList5.item(i5);
				Element eElement5 = (Element) nNode5;
//				System.out.println("username : " + eElement5.getElementsByTagName("username").item(0).getTextContent());
//				System.out.println("password : " + eElement5.getElementsByTagName("password").item(0).getTextContent());
//				System.out.println("fname : " + eElement5.getElementsByTagName("fname").item(0).getTextContent());
//				System.out.println("lname : " + eElement5.getElementsByTagName("fname").item(0).getTextContent());
				
				use.add(new user());
				use.get(i5).setUsername(eElement5.getElementsByTagName("username").item(0).getTextContent());
				use.get(i5).setPassword(eElement5.getElementsByTagName("password").item(0).getTextContent());
				use.get(i5).setFname(eElement5.getElementsByTagName("fname").item(0).getTextContent());
				use.get(i5).setLname(eElement5.getElementsByTagName("lname").item(0).getTextContent());
				
				
				
				Element eElement51 = (Element) eElement5.getElementsByTagName("following").item(0);
				NodeList nList51 = eElement51.getElementsByTagName("username");
				for (int i51=0;i51<nList51.getLength();i51++)
				{
//					System.out.println("following : " +nList51.item(i51).getTextContent());
					use.get(i5).addFollower(nList51.item(i51).getTextContent());
				}
				Element eElement52 = (Element) eElement5.getElementsByTagName("feed").item(0);
				NodeList nList52 = eElement52.getElementsByTagName("event");
				for (int i52=0;i52<nList52.getLength();i52++)
				{
					
					use.get(i5).addEvent(new event(eElement5.getElementsByTagName("action").item(i52).getTextContent(),
							eElement5.getElementsByTagName("rating").item(i52).getTextContent(),
							eElement5.getElementsByTagName("movie").item(i52).getTextContent()));
//					System.out.println("action : " + eElement5.getElementsByTagName("action").item(0).getTextContent());
//					System.out.println("movie : " + eElement5.getElementsByTagName("movie").item(0).getTextContent());
//					System.out.println("rating : " + eElement5.getElementsByTagName("rating").item(0).getTextContent());
					
				}
				
			}	
			return (use);
		}catch (Exception e) 
		{
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	
	
	
	
	
	
	public static void main(String []args) {
		
		XMLReader x = new XMLReader();
	
		ArrayList<user> users = x.readUsers();
		ArrayList<movie> movies = x.readMovies();
		ArrayList<String> temp = new ArrayList<String>();
		user tempuser = users.get(0);
		int stage = 1;
		int counter=0;
		int counter2=0;
		String a;
		String b;
		String c;
		String d;
		String e;
		String f;
		String g;
		String h;
		String i;
		String pass = "";
		Scanner s = new Scanner(System.in);
		while (true)
		{
			// log in
			if (stage == 1)
			{
				System.out.println("1. Login");
				System.out.println("2. Exit");
				a = s.nextLine();
				if (!a.equals("1") && !a.equals("2"))
				{
					System.out.println("You have entered an invalid command, please try again.");
				}
				else if (a.equals("1"))
				{
					stage = 2;
					counter = 3;
				}
				else
				{
					s.close();
					System.exit(0);
				}
			}
			//username
			else if (stage == 2)
			{
				System.out.println("Please enter your username");
				b = s.nextLine();
				boolean test = false;
				for (int u2 =0; u2<users.size();u2++)
				{
					if (users.get(u2).getUsername().equals(b))
					{
						test = true;
						pass = users.get(u2).getPassword();
						tempuser = users.get(u2);
//						System.out.println(pass);
					}
				}
				if (test == true)
				{
					stage = 3;
					counter2 =3;
				}
				else
				{
					counter--;
					if (counter != 0)
					{
						System.out.println("Invalid username. You have "+counter+" more chances to enter a valid username.");
					}
					else
					{
						stage = 1;
					}
				}
			}
			//password
			else if (stage == 3)
			{
				System.out.println("Please enter your password");
				c = s.nextLine();
				counter2--;
				if (c.equals(pass) )
				{
					stage = 4;
				}
				else if (counter2 !=0)
				{
					System.out.println("Incorrect password. You have "+counter2+" more chances to enter a valid username.");
				}
				else
				{
					stage =1;
				}
			}
			//main menu
			else if (stage ==4)
			{
				System.out.println("1. Search Users");
				System.out.println("2. Search Movies");
				System.out.println("3. View Feed");
				System.out.println("4. View Profile");
				System.out.println("5. Logout");
				System.out.println("6. Exit");
				d = s.nextLine();
				
				if (d.equals("5") )
				{
					stage = 1;
				}
				// close program
				else if (d.equals("6"))
				{
					s.close();
					System.exit(0);
				}
				else if (d.equals("1"))
				{
					stage = 5;
				} 
				else if (d.equals("2"))
				{
					stage = 6;
				}
				//view feed
				else if (d .equals("3"))
				{
					System.out.println("Feed:");
					ArrayList<user> f2 = tempuser.getFollowers(users);
					ArrayList<event> e2 = tempuser.getEvents();
					for (event e4 : e2)
					{
						System.out.println(tempuser.getUsername() +" "+ e4.printEvent());
					}
					for (user u : f2)
					{
							e2 = u.getEvents();
							for (event e3 : e2)
							System.out.println(u.getUsername() +" "+ e3.printEvent());
					}
					
				}
				//view profile
				else if (d .equals("4"))
				{
					System.out.println(tempuser.getFname() + " " +tempuser.getLname());
					System.out.println("username: "+tempuser.getUsername());
					if (tempuser.getPassword().length()<3)
					{
						System.out.println("password: "+ tempuser.getPassword());
					}
					else
					{
						System.out.print("password: "+ tempuser.getPassword().substring(0,1));
						int size =tempuser.getPassword().length();
						for (int i2=0;i2<size-2;i2++)
						{
							System.out.print("*");
						}
						System.out.println(tempuser.getPassword().substring(size-1,size));
					}
					
					System.out.println("Following: ");
					ArrayList<user> fo = tempuser.getFollowers(users);
					for (user u : fo)
					{
						System.out.println(u.getFname() + " " +u.getLname());
					}
					System.out.println("Followers: ");
					ArrayList<user> following = new ArrayList<user> ();
					following = tempuser.getMyFollowers(users);
					for (user us3: following)
					{
						System.out.println(us3.getUsername());
					}
					System.out.println("To go back to the login menu, please type ‘0’");
					while (!s.nextLine().equals("0") )
					{
						System.out.println("Invalid command. To go back to the login menu, please type ‘0’");
					}
				}
				else
				{
						System.out.println("You have entered an invalid command, please try again.");

				}
			}
			else if (stage ==5)
			{
				temp.clear();
				System.out.println("Please enter the username you are searching for.");
				e = s.nextLine();
				int result = 0;
				for (user u5 : users)
				{
					if (u5.getUsername().toLowerCase() .equals(e.toLowerCase()) )
					{
						temp.add(u5.getUsername());
						result++;
					}
				}
				System.out.println(result +"  result:");
				for (String s2 : temp)
				{
					System.out.println(s2);
				}	
				while (true)
				{
					System.out.println("Please choose from the following options:");
					System.out.println("1. Back to Login Menu");
					System.out.println("2. Search Again");
					f = s.nextLine();
					if (!f.equals("1")  && !f.equals("2") )
					{
						System.out.println("invalid input");
					}
					else if (f.equals("1"))
					{
						stage = 4;
						break;
					}
					else
					{
						break;
					}
				}

				
			}
			else if (stage ==6)
			{
				while (true)
				{
					System.out.println("1. Search by Actor");
					System.out.println("2. Search by Title");
					System.out.println("3. Search by Genre");
					System.out.println("4. Back to Login Menu");
					g = s.nextLine();

					if (!g.equals("1") && !g.equals("2") &&!g.equals("3") &&!g.equals("4") )
					{
						System.out.println("invalid input");
					}
					else
					{
						break;		
					}
				}
				if (g.equals("1"))
				{
					temp.clear();
					System.out.println("Please enter the name of the actor you wish to search by.");
					int result2 =0;
					h = s.nextLine();
					ArrayList<String> ats = new ArrayList<String>();
					
					for (movie m4 : movies)
					{
						ats = m4.getActors(); 
						for (String s5:ats)
						{
							if (s5.toLowerCase() .equals(h.toLowerCase()) )
							{
								result2++;
								temp.add(m4.getTitle());
							}
						}
					}
					System.out.println(result2 +" result:");
					for (String s6 : temp)
					{
						System.out.println("'"+s6+"'");
					}
					while (true)
					{
						System.out.println("Please choose from the following options:");
						System.out.println("1. Back to Login Menu");
						System.out.println("2. Back to Search Movies Menu");
						h = s.nextLine();
						if (h.equals("1"))
						{
							stage =4;
							break;
						}
						else if (h.equals("2"))
						{
							break;
						}
						else
						{
							System.out.println("invalid input");
						}
					}
					
					
					
					
					
					
					
					
				}
				else if (g.equals("2"))
				{
					temp.clear();
					System.out.println("Please enter the name of the title you wish to search by.");
					int result3 =0;
					i = s.nextLine();
					for (movie m : movies)
					{
						if (i.toLowerCase().equals(m.getTitle().toLowerCase()) )
						{
							temp.add(m.getTitle());
							result3++;
						}
					}
					System.out.println(result3 +" result:");
					for (String s3 : temp)
					{
						System.out.println("'"+s3+"'");
					}
					while (true)
					{
						System.out.println("Please choose from the following options:");
						System.out.println("1. Back to Login Menu");
						System.out.println("2. Back to Search Movies Menu");
						i = s.nextLine();
						if (i.equals("1"))
						{
							stage =4;
							break;
						}
						else if (i.equals("2"))
						{
							break;
						}
						else
						{
							System.out.println("invalid input");
						}
					}
				}
				else if (g.equals("3"))
				{
					temp.clear();
					System.out.println("Please enter the name of the genre you wish to search by.");
					int result4 =0;
					g = s.nextLine();
					for(movie m3 : movies)
					{
						if (m3.getGenre().toLowerCase().equals(g.toLowerCase()) )
						{
							temp.add(m3.getTitle());
							result4++;
						}
					}
					System.out.println(result4 +" result:");
					for (String s4 : temp)
					{
						System.out.println("'"+s4+"'");
					}
					while (true)
					{
						System.out.println("Please choose from the following options:");
						System.out.println("1. Back to Login Menu");
						System.out.println("2. Back to Search Movies Menu");
						g = s.nextLine();
						if (g.equals("1"))
						{
							stage =4;
							break;
						}
						else if (g.equals("2"))
						{
							break;
						}
						else
						{
							System.out.println("invalid input");
						}
					}
					
				}
				else if (g.equals("4"))
				{
					stage = 4;
				}
			}
		
		}
	}
}


