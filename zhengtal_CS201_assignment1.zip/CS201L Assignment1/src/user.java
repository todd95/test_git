import java.util.*;

public class user {
	private String username;
	private String password;
	private String fname;
	private String lname;
	private ArrayList<String> follower = new ArrayList<String>();
	private ArrayList<event> feed = new ArrayList<event>();
	private ArrayList<user> myfollowers = new ArrayList<user>();
	
	public user(){};
	
	public void setUsername(String n)
	{
		username = n;
	}
	public void setPassword(String p)
	{
		password = p;
	}
	public void setFname(String f)
	{
		fname = f;
	}
	public void setLname(String l)
	{
		lname = l;
	}
	public void addFollower(String u)
	{
		follower.add(u);
	}
	public void addEvent(event e)
	{
		feed.add(e);
	}
	
	
	
	public String getUsername()
	{
		return username;
	}
	public String getPassword()
	{
		return password;
	}
	public String getFname()
	{
		return fname;
	}
	public String getLname()
	{
		return lname;
	}
	public ArrayList<user> getFollowers(ArrayList<user> au)
	{
		ArrayList<user> temp = new ArrayList<user>();
		for (String s2 : follower)
		{
			for (user u2 : au)
			{
				if (u2.getUsername().equals(s2))
				{
					temp.add(u2);
				}
			}
		}
		return temp;
	}
	public ArrayList<event> getEvents()
	{
		return feed;
	}
//	public String printPassword()
//	{
//		int a = password.length();
//		if (a<3)
//		{
//			return password;
//		}
//		String star = "";
//		star.
//		
//		return (password.substring(0,1)+);
//	}
	public ArrayList<user> getMyFollowers(ArrayList<user> list)
	{
		myfollowers.clear();
		ArrayList<user> u3;
		for (user us : list)
		{
			u3 = us.getFollowers(list);
			for (user uss : u3)
			{
				if (uss.getUsername().equals(username) && !us.equals(this))
				{
					myfollowers.add(us);
				}
			}
		}
		return myfollowers;
	}
	
}
