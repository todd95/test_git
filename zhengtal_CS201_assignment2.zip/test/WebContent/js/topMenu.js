window.onload = function(){
	var feedButton = document.getElementById("feed-button");
	var profileButton = document.getElementById("profile-button");
	var toggleButton = document.getElementById("toggle-button");
	var searchButton = document.getElementById("search-button");
	var logoutButton = document.getElementById("logout-button");
	var exitButton = document.getElementById("exit-button");
	
	feedButton.src ="img/feed_icon.png";
	feedButton.style.height = '50px';
	feedButton.style.width = '50px';
	
	profileButton.src ="img/profile_image_default.png";
	profileButton.style.height = '50px';
	profileButton.style.width = '50px';
	
	toggleButton.src ="img/clapperboard_icon.png";
	toggleButton.style.height = '50px';
	toggleButton.style.width = '50px';
	
	searchButton.src ="img/search_icon.png";
	searchButton.style.height = '50px';
	searchButton.style.width = '50px';
	
	logoutButton.src ="img/logout_icon.png";
	logoutButton.style.height = '50px';
	logoutButton.style.width = '50px';
	
	exitButton.src ="img/exit_icon.jpg";
	exitButton.style.height = '50px';
	exitButton.style.width = '50px';
};


//	var topMenu = document.getElementById("hi");
//	var img = document.createElement("img");
//	var img2 = document.createElement("p");
//	img2.innerHTML ="hello";
//	img.src = "http://www.google.com/intl/en_com/images/logo_plain.png";	topMenu.appendChild(img2);
//	
//	
	
	

//
//	
//	feedButton.src ="img/feed_icon.png";
//
//	topMenu.appendChild(feedButoon);



